﻿Project for testing some sparse matrix-vector and matrix-matrix multiplication wiht CUDA and .net.

All matrices are in CSR format. The code contains different CUDA kernels for multiply sparse matrix vs dense vector and sparse matrix vs another sparse matrix.  It contains several cuda kernel for sparse matrix dense vector product and sparse matrix sparse matrix product. 


Author: Krzysztof Sopyła (ksirg@wp.pl)

If you want to use it or find any bug please let me know.